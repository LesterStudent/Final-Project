PROJECT BLOCKCHAIN JAVASCRIPT

This program was written in javascript therefore it is required to install the software Node.js, gitbash and also a text editor.
The text editor I used was Visual Studio Code as it was the best text editor for me.
The 2 programs are different but form similar functions.

Data Miner
Data miner mines data, applies a hash and provides a reward to the user. The user must load the folder into the text editor. The files the user
can execute are blockchain.js, keygenerator.js and main.js. To execute the program, the user type in the terminal node "filename"
e.g. node main.js then the program is run. The user can also edit the program.

Transactions
Transactions program executes lines of print statments but each statement is applied a hash, timestamp, and an amount. This folder has fewer files.
Therefore the user can simply run the main.js file by using the same terminal line, node main.js.


Signed by,
Lester Gonsalves
Student
Queen Mary University of London 
